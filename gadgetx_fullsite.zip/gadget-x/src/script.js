// Product list with original & 40% prices
const products = [
  { title: "iPhone XR (64GB)", price: 250000, img: "images/1.jpg" },
  { title: "iPhone 11 Pro Max (64GB)", price: 380000, img: "images/2.jpg" },
  { title: "iPhone 12 Pro Max (128GB)", price: 327000, img: "images/3.jpg" },
  { title: "iPhone 12 Pro Max (256GB)", price: 580000, img: "images/4.jpg" },
  { title: "iPhone 13 Pro Max (128GB)", price: 500000, img: "images/5.jpg" },
  { title: "iPhone 14 Pro Max (256GB)", price: 900000, img: "images/6.jpg" },
  { title: "iPad Mini (12th Gen)", price: 200000, img: "images/7.jpg" },
  { title: "Earpods Pro", price: 70000, img: "images/8.jpg" },
  { title: "Oraimo Power Bank (40,000 mAh)", price: 42000, img: "images/9.jpg" },
  { title: "Tri-pod + Ring Light", price: 28500, img: "images/10.jpg" },
  { title: "Apple Smart Watch", price: 200000, img: "images/11.jpg" },
  { title: "Samsung S22 Ultra", price: 700000, img: "images/12.jpg" }
];

const container = document.getElementById("product-list");

products.forEach((p, i) => {
  const inst = Math.round(p.price * 0.4);
  const card = document.createElement("div");
  card.className = "product-card";
  card.innerHTML = `
    <img src="${p.img}" alt="${p.title}">
    <div class="card-body">
      <h3>${p.title}</h3>
      <p class="price">Original: ₦${p.price.toLocaleString()}<br>
      <span>40% Upfront: ₦${inst.toLocaleString()}</span></p>
      <button class="buy-btn" onclick="payNow(${inst}, '${p.title}')">Buy Now</button>
    </div>`;
  container.appendChild(card);
});

function payNow(amount, title) {
  FlutterwaveCheckout({
    public_key: "FLWPUBK-2b01ca9653cbf025d8843ce27e456c4b-X",
    tx_ref: "GadgetX-" + Date.now(),
    amount: amount,
    currency: "NGN",
    payment_options: "card, banktransfer, ussd",
    customer: {
      email: "customer@example.com",
      phone_number: "08000000000",
      name: "Gadget X Customer"
    },
    customizations: {
      title: "Gadget X",
      description: title,
      logo: ""
    },
    callback: function (data) {
      const formLink = "https://form.svhrt.com/68ee7fa9c526e9f3b64609a9";
      window.open(formLink + "?tx_ref=" + data.tx_ref, "_blank");
    },
    onclose: function() {
      alert("Payment window closed.");
    }
  });
}